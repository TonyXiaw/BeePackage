package com.little_hope.workstep.notifikasi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import com.little_hope.workstep.Masuk;
import com.little_hope.workstep.R;


public class Daftar_berhasil extends AppCompatActivity {
    Button ok;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_berhasil);
        ok=findViewById(R.id.btnOk);

        ok.setOnClickListener(view -> {
            Intent inten=new Intent(Daftar_berhasil.this, Masuk.class);
            startActivity(inten);
        });
    }
}