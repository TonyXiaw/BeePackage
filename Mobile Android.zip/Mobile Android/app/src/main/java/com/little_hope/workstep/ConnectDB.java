package com.little_hope.workstep;

import android.app.Application;

public class ConnectDB extends Application {
    public static String global_ipaddress="http://10.0.2.2";//ip address AVD EMULATOR
    //public static String global_ipaddress="http://192.168.1.1";//TATERING WIFI/LAN
    public static String URL=global_ipaddress+"/workstep/android/";

    public static String getURL() {
        return URL;
    }
    public static Integer idpekerja=0;
    public static String nama="";
    public static String universitas="";
    public static String jurusan="";
    public static String email="";


    public static Integer score=0;
    public static String judul_task="";
    public static String tingkat_text="";
    public static Integer tingkat_warna=0;
    public static String deskripsi_task="";

    public static Integer totalscoreTask=0;

    public static String namaPerusahaan="";
    public static String tanggal="";
    public static String deskripsiProyek="";
    public static String contact="";

    public static String namaJd="";
    public static Integer idJd=0;

}
