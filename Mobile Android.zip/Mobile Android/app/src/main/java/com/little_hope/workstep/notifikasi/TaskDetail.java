package com.little_hope.workstep.notifikasi;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.little_hope.workstep.ConnectDB;
import com.little_hope.workstep.MainActivity;
import com.little_hope.workstep.R;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;


public class TaskDetail extends AppCompatActivity {
    TextView namatask,score,tingkat,deskripsi,kembali,namafile;
    ImageView kembali2;
    Button selesai,upload;
    private final int PICK_PDF_REQUEST = 1;
    private Uri fileUri;
    RequestQueue requestQueque;
    StringRequest stringRequest;
    String check="sedang dinilai";

    private String convertPDFToBase64(Uri fileUri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(fileUri);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                byteArrayOutputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            byte[] pdfBytes = byteArrayOutputStream.toByteArray();
            return Base64.encodeToString(pdfBytes, Base64.DEFAULT);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    private String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    result = cursor.getString(index);
                }
            }
        }
        if (result == null) {
            result = uri.getLastPathSegment();
        }
        return result;
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_PDF_REQUEST && resultCode == RESULT_OK && data != null) {
            fileUri = data.getData();
            if (fileUri != null) {
                String fileName = getFileName(fileUri);
                namafile.setText("File Dipilih: " + fileName);
                Toast.makeText(this, "File dipilih: " + fileUri.getLastPathSegment(), Toast.LENGTH_SHORT).show();
                // TODO: Implementasikan upload file;
            }
        }
    }
    private void selectPDF() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/pdf");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(intent, "Pilih File PDF"), PICK_PDF_REQUEST);
    }


    private void konekDB(String aksi){
        String pdfBase64 = convertPDFToBase64(fileUri);
        if (pdfBase64 == null) {
            Toast.makeText(this, "Gagal mengonversi file!", Toast.LENGTH_SHORT).show();
            return;
        }
        stringRequest=new StringRequest(Request.Method.POST,
                ((ConnectDB) getApplication()).getURL() + "kirimtask.php",
                response -> {
                    Log.d("Server Response", response);  // Log the raw response
                    try {
                        JSONObject jboj= new JSONObject(response);
                        String pesan=jboj.getString("pesan");
                        boolean hasil=jboj.getBoolean("hasil");
                        Toast.makeText(getApplicationContext(),pesan, Toast.LENGTH_LONG).show();
                        if(hasil){
                            if(aksi.equalsIgnoreCase("kirimtask")){
                                finishAffinity();
                                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                            }
                        }
                    }catch (JSONException e){
                        e.printStackTrace();
                        Log.e("JSON Error", "Failed to parse JSON: " + e.getMessage());
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(getApplicationContext(),"Gagal Menghubungi server : "+
                        error.getMessage(),Toast.LENGTH_LONG).show())//akhir error listener
        {
            @Override
            protected Map<String,String> getParams()throws AuthFailureError {
                Map<String,String>param= new HashMap<>();
                if(aksi.equalsIgnoreCase("kirimtask"))
                    param.put("aksi","kirimtask");
                param.put("nama",ConnectDB.nama);
                param.put("nama_task",ConnectDB.judul_task);
                param.put("tugas", pdfBase64);
                param.put("score", String.valueOf(ConnectDB.score));
                param.put("status", check);
                return param;
            }

        };//------------------- akhir string request----------------------------------------

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));
        requestQueque= Volley.newRequestQueue(getApplicationContext());
        requestQueque.add(stringRequest);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_detail);

        namatask=findViewById(R.id.txtNamaTask);
        tingkat=findViewById(R.id.txtTingkat);
        score=findViewById(R.id.txtScoreTask);
        deskripsi=findViewById(R.id.txtDeskripsi);
        kembali=findViewById(R.id.btnKembali);
        kembali2=findViewById(R.id.btnKembali2);
        selesai=findViewById(R.id.btnSelesaiTask);
        upload=findViewById(R.id.btnUploadTask);
        namafile=findViewById(R.id.txtNamaFile);



        namatask.setText(ConnectDB.judul_task);
        score.setText(String.valueOf(ConnectDB.score));
        tingkat.setText(ConnectDB.tingkat_text);
        tingkat.setTextColor(ConnectDB.tingkat_warna);
        deskripsi.setText(ConnectDB.deskripsi_task);




        upload.setOnClickListener(view -> selectPDF());

        kembali.setOnClickListener(view -> {
            Intent intent = new Intent(TaskDetail.this, MainActivity.class);
            startActivity(intent);
        });
        kembali2.setOnClickListener(view -> {
            Intent intent = new Intent(TaskDetail.this, MainActivity.class);
            startActivity(intent);
        });
        selesai.setOnClickListener(view -> {
            if (fileUri == null) {
                Toast.makeText(this, "Harap upload file PDF terlebih dahulu!", Toast.LENGTH_SHORT).show();
                return; // Hentikan eksekusi
            }
            konekDB("kirimtask");

        });
    }
}