package com.little_hope.workstep.notifikasi;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.little_hope.workstep.ConnectDB;
import com.little_hope.workstep.Masuk;
import com.little_hope.workstep.R;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LupaPassword extends AppCompatActivity {
    TextView mail, code, pass;
    Button btnRequest, ok;
    RequestQueue requestQueue;
    StringRequest stringRequest;

    private void requestOTP() {
        String url = ConnectDB.getURL() + "requestnewpassword.php"; // URL server

        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        boolean hasil = jsonObject.getBoolean("hasil");
                        String pesan = jsonObject.getString("pesan");
                        Toast.makeText(this, pesan, Toast.LENGTH_LONG).show();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Error parsing response", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Gagal menghubungi server", Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("aksi", "email");
                params.put("email", mail.getText().toString().trim());
                return params;
            }
        };

        queue.add(request);
    }

    private void verifyAndResetPassword() {
        String url = ConnectDB.getURL() + "requestnewpassword.php"; // URL server

        stringRequest = new StringRequest(Request.Method.POST, url,
                response -> {
                    Log.d("Server Response", response);
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        boolean hasil = jsonObject.getBoolean("hasil");
                        String pesan = jsonObject.getString("pesan");
                        Toast.makeText(getApplicationContext(), pesan, Toast.LENGTH_LONG).show();
                        if (hasil) {
                            finishAffinity();
                            startActivity(new Intent(getApplicationContext(), Masuk.class));
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Log.e("JSON Error", "Failed to parse JSON: " + e.getMessage());
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(getApplicationContext(), "Gagal Menghubungi server: " +
                        error.getMessage(), Toast.LENGTH_LONG).show()) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("aksi", "verifikasi");
                params.put("email", mail.getText().toString().trim());
                params.put("code", code.getText().toString().trim());
                params.put("pass", pass.getText().toString().trim());
                return params;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lupa_password);

        mail = findViewById(R.id.txtEmailLp);
        btnRequest = findViewById(R.id.btnRequest);
        code = findViewById(R.id.txtCode);
        ok = findViewById(R.id.btnLp);
        pass = findViewById(R.id.txtPassLp);

        btnRequest.setOnClickListener(v -> {
            String email = mail.getText().toString().trim();
            if (email.isEmpty()) {
                Toast.makeText(this, "Masukkan email terlebih dahulu", Toast.LENGTH_SHORT).show();
            } else {
                requestOTP();
            }
        });

        ok.setOnClickListener(view -> {
            if (mail.getText().toString().trim().isEmpty() ||
                    !Patterns.EMAIL_ADDRESS.matcher(mail.getText()).matches()) {
                mail.setError("Format email salah, contoh: email@email.com");
                mail.requestFocus();
            } else if (code.getText().toString().trim().isEmpty()) {
                code.setError("Masukkan kode verifikasi dari email");
                code.requestFocus();
            } else {
                String passwordText = pass.getText().toString();
                String regex = "^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[!@#$%^&*(),.?\":{}|<>]).{8,}$";

                // Membuat Pattern dan Matcher
                Pattern pattern = Pattern.compile(regex);
                Matcher matcher = pattern.matcher(passwordText);

                if (!matcher.matches()) {
                    pass.setError("Password harus mengandung huruf, angka, dan simbol dengan panjang minimal 8 karakter.");
                    pass.requestFocus();
                } else {
                    verifyAndResetPassword();
                }
            }
        });
    }
}
