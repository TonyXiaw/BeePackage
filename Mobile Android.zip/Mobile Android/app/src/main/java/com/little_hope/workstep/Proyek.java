package com.little_hope.workstep;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.little_hope.workstep.adapter.ProyekAdapter;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class Proyek extends AppCompatActivity {
    ProyekAdapter adapter;
    ImageView home,cari,keluar,jobdesk;
    EditText searchInput;
    RequestQueue requestQueue;
    TextView client,name,tanggal,deskripsi;
    StringRequest stringRequest;
    private int searchClickCount = 0;
    ArrayList<HashMap<String, String>> arrayList = new ArrayList<>();



    private void filterData(String keyword) {
        ArrayList<HashMap<String, String>> filteredList = new ArrayList<>();

        for (HashMap<String, String> map : arrayList) {
            String taskName = map.get("nama_client");
            if (taskName.toLowerCase().contains(keyword.toLowerCase())) {
                filteredList.add(map);
            }
        }

        adapter.updateData(filteredList);
    }
    private void konekDB(String aksi){
        //akhir onResponse
        stringRequest = new StringRequest(Request.Method.POST,
                ((ConnectDB) getApplication()).getURL() + "proyek.php",
                response -> {
                    Log.d("LoginResponse", response); // Log response untuk debugging
                    try {
                        JSONObject jObj = new JSONObject(response);
                        //String pesan = jObj.getString("pesan");
                        boolean hasil = jObj.getBoolean("hasil");
                        //Toast.makeText(getApplicationContext(), pesan, Toast.LENGTH_LONG).show();
                        if(hasil) {
                            if(aksi.equalsIgnoreCase("proyek")){
                                JSONArray jsonArray = jObj.getJSONArray("resDataProyek");
                                for (int a = 0; a < jsonArray.length(); a++) {
                                    JSONObject json = jsonArray.getJSONObject(a);
                                    HashMap<String, String> map = new HashMap<>();
                                    map.put("nama_client", json.getString("nama_client"));
                                    map.put("tanggal_proyek", json.getString("tanggal_proyek"));
                                    map.put("deskripsi_proyek", json.getString("deskripsi_proyek"));
                                    map.put("contact", json.getString("contact"));
                                    arrayList.add(map);
                                }
                                Log.d("Proyek", "Jumlah data di arrayList: " + arrayList.size());
                                adapter.notifyDataSetChanged();
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }, //akhir Listener
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Gagal menghubungi server : " +
                                error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }) //akhir ErrorListener dan new StringRequest
        {   @Override
        protected Map<String,String> getParams() throws AuthFailureError {
            Map<String, String> param = new HashMap<>();
            if(aksi.equalsIgnoreCase("proyek"))
                param.put("aksi","proyek");

            return param;
        }
        }; //akhir stringRequest =
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    } //akhir method konekDB
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proyek);

        client=findViewById(R.id.txtClient);
        home=findViewById(R.id.btnBeranda);
        cari=findViewById(R.id.btnCari);
        searchInput=findViewById(R.id.inputCari);
        keluar=findViewById(R.id.btnKeluarProyek);
        name=findViewById(R.id.txtname);
        jobdesk=findViewById(R.id.btnjobdesk);
        tanggal=findViewById(R.id.txtTgl);
        deskripsi=findViewById(R.id.textDes);

        RecyclerView recyclerView = findViewById(R.id.rvProyek);
        adapter = new ProyekAdapter(this, arrayList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        name.setText(ConnectDB.nama);
        konekDB("proyek");


        home.setOnClickListener(view -> {
            Intent intent = new Intent(Proyek.this, MainActivity.class);
            startActivity(intent);
        });
        keluar.setOnClickListener(view -> {
            finishAffinity();
            startActivity(new Intent(getApplicationContext(), Keluar.class));
        });
        jobdesk.setOnClickListener(view -> {
            Intent intent=new Intent(Proyek.this,Jobdesk.class);
            startActivity(intent);
        });

        cari.setOnClickListener(v -> {
            searchClickCount++;

            if (searchClickCount == 1) {
                searchInput.setVisibility(View.VISIBLE);
            } else if (searchClickCount == 2) {
                searchInput.setVisibility(View.GONE);
                searchClickCount = 0;
            }

            // Reset klik jika tidak diklik lagi dalam 0.5 detik
            cari.postDelayed(() -> searchClickCount = 0, 500);
        });


        // Filter saat mengetik
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterData(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }
}