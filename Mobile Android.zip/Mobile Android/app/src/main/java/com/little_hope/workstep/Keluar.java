package com.little_hope.workstep;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.little_hope.workstep.notifikasi.Keluar_berhasil;

public class Keluar extends AppCompatActivity {
    Button yes,no;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keluar);
        yes=findViewById(R.id.btnYes);
        no=findViewById(R.id.btnNo);

        yes.setOnClickListener(view -> {
            finishAffinity();
            startActivity(new Intent(getApplicationContext(), Keluar_berhasil.class));
        });
        no.setOnClickListener(view -> {
            Intent intent = new Intent(Keluar.this,MainActivity.class);
            startActivity(intent);
        });



    }
}