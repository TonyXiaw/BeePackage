package com.little_hope.workstep;



import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class SplashScreen extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        Thread timer= new Thread(() -> {
            try {
                Thread.sleep(2500);
            }catch (InterruptedException e){
                Toast.makeText(getApplicationContext(), e.getMessage(),
                        Toast.LENGTH_LONG).show();
            }finally {
                Intent intent=new Intent(getApplicationContext(),Masuk.class);
                startActivity(intent);
                finish();
            }
        });timer.start();
    }
}