package com.little_hope.workstep;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.little_hope.workstep.notifikasi.Daftar_berhasil;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Daftar extends AppCompatActivity {
    TextView nama,usia,kampus,jurusan,hp,email,password;
    Button daftar;
    String gender;
    RequestQueue requestQueque;
    StringRequest stringRequest;
    RadioGroup kelamin;
    RadioButton laki,wanita;



    //fungsi konekdb
    private void konekDB(String aksi){
        stringRequest=new StringRequest(Request.Method.POST,
                ((ConnectDB) getApplication()).getURL() + "daftar.php",
                response -> {
                    Log.d("Server Response", response);  // Log the raw response
                    try {
                        JSONObject jboj= new JSONObject(response);
                        String pesan=jboj.getString("pesan");
                        boolean hasil=jboj.getBoolean("hasil");
                        Toast.makeText(getApplicationContext(),pesan, Toast.LENGTH_LONG).show();
                        if(hasil){
                            if(aksi.equalsIgnoreCase("daftar")){
                                finishAffinity();
                                startActivity(new Intent(getApplicationContext(), Daftar_berhasil.class));
                            }
                        }
                    }catch (JSONException e){
                        e.printStackTrace();
                        Log.e("JSON Error", "Failed to parse JSON: " + e.getMessage());
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(getApplicationContext(),"Gagal Menghubungi server : "+
                        error.getMessage(),Toast.LENGTH_LONG).show())//akhir error listener
        {
            @Override
            protected Map<String,String> getParams()throws AuthFailureError {
                Map<String,String>param= new HashMap<>();
                if(aksi.equalsIgnoreCase("daftar"))
                    param.put("aksi","daftar");

                param.put("nama",nama.getText().toString().trim());
                param.put("usia",usia.getText().toString().trim());
                param.put("gender",gender);
                param.put("hp",hp.getText().toString().trim());
                param.put("kampus",kampus.getText().toString().trim());
                param.put("email",email.getText().toString().trim());
                param.put("pass",password.getText().toString().trim());
                param.put("jurusan",jurusan.getText().toString().trim());

                return param;
            }

        };//------------------- akhir string request----------------------------------------

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));
        requestQueque= Volley.newRequestQueue(getApplicationContext());
        requestQueque.add(stringRequest);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar);
        nama=findViewById(R.id.txtNama);
        usia=findViewById(R.id.txtUsia);
        kampus=findViewById(R.id.txtKampus);
        jurusan=findViewById(R.id.txtJurusan);
        hp=findViewById(R.id.txtHp);
        email=findViewById(R.id.txtEmail);
        password=findViewById(R.id.txtPassword);
        daftar=findViewById(R.id.btnDaftar);
        kelamin=findViewById(R.id.rgGender);
        laki=findViewById(R.id.rdPria);
        wanita=findViewById(R.id.rdWanita);
        daftar.setOnClickListener(view -> {
            if (hp.length() < 10) {
                hp.setError("Angka harus diisi 10 angka");
                hp.requestFocus();
            } else if (nama.getText().toString().trim().isEmpty()) {
                nama.setError("Nama Wajib Diisi");
                nama.requestFocus();
            } else if (usia.getText().toString().trim().isEmpty()) {
                usia.setError("Usia Wajib Diisi");
                usia.requestFocus();
            } else if (kampus.getText().toString().trim().isEmpty()) {
                kampus.setError("Nama Kampus Wajib Diisi");
                kampus.requestFocus();
            } else if (jurusan.getText().toString().trim().isEmpty()) {
                jurusan.setError("Nama Kampus Wajib Diisi");
                jurusan.requestFocus();
            } else if (!email.getText().toString().trim().isEmpty()
                    && !Patterns.EMAIL_ADDRESS.matcher(email.getText()).matches()) {
                email.setError("Formal email salah harusnya email@email.com");
                email.requestFocus();

            } else {
                String passwordText = password.getText().toString();
                String regex = "^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[!@#$%^&*(),.?\":{}|<>]).{8,}$";

                // Membuat Pattern dan Matcher
                Pattern pattern = Pattern.compile(regex);
                Matcher matcher = pattern.matcher(passwordText);

                if (!matcher.matches()) {
                    password.setError("Password harus mengandung huruf, angka, dan simbol dengan panjang minimal 8 karakter.");
                    password.requestFocus();
                } else {
                    // Mendapatkan pilihan gender
                    int jenis = kelamin.getCheckedRadioButtonId();
                    RadioButton jenkel = findViewById(jenis);
                    gender = jenkel.getText().toString();

                    // Mengirim data ke server
                    konekDB("daftar");
                }

            }
        });

    }
}