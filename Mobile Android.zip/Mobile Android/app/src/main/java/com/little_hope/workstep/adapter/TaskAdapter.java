package com.little_hope.workstep.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.little_hope.workstep.ConnectDB;
import com.little_hope.workstep.R;
import com.little_hope.workstep.notifikasi.TaskDetail;
import java.util.ArrayList;
import java.util.HashMap;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.ViewHolder> {
    private final Context context;
    private ArrayList<HashMap<String, String>> listData;

    public TaskAdapter(Context context, ArrayList<HashMap<String, String>> listData) {
        this.context = context;
        this.listData = listData;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_task, null);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(TaskAdapter.ViewHolder holder, int position) {
        HashMap<String, String> map = listData.get(position);
        // Ambil nilai score dan ubah menjadi integer
        String scoreStr = map.get("score");
        int score = (scoreStr != null && !scoreStr.isEmpty()) ? Integer.parseInt(scoreStr) : 0;

        // Tentukan tingkat kesulitan dan warna
        String tingkatKesulitan;
        int warna;
        if (score >= 1 && score <= 30) {
            tingkatKesulitan = "Rendah";
            warna = Color.GREEN;
        } else if (score > 30 && score <= 70) {
            tingkatKesulitan = "Sedang";
            warna = Color.YELLOW;
        } else {
            tingkatKesulitan = "Susah";
            warna = Color.RED;
        }

        // Set teks dan warna di txtKesulitan
        holder.kesulitan.setText(tingkatKesulitan);
        holder.kesulitan.setTextColor(warna);
        holder.txtJudulTask.setText(map.get("nama_task"));
        holder.score.setText(map.get("score"));

        holder.itemView.setOnClickListener(v -> {
            // Simpan data ke ConnectDB
            ConnectDB.judul_task = map.get("nama_task");
            //ConnectDB.idpekerja = position; // Contoh: menyimpan ID posisi
            //ConnectDB.judul = ;
            ConnectDB.score = score;
            ConnectDB.tingkat_text = tingkatKesulitan; // Simpan teks kesulitan
            ConnectDB.tingkat_warna = warna; // Simpan warna kesulitan
            ConnectDB.deskripsi_task=map.get("description");
            // Pindah ke TaskDetail
            Intent intent = new Intent(context, TaskDetail.class);
            context.startActivity(intent);
        });

    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtJudulTask,score,kesulitan;

        public ViewHolder( View itemView) {
            super(itemView);
            txtJudulTask = itemView.findViewById(R.id.txtJudulTask);
            score = itemView.findViewById(R.id.txtScore);
            kesulitan = itemView.findViewById(R.id.txtKesulitan);

        }
    }
    public void updateData(ArrayList<HashMap<String, String>> newData) {
        this.listData = newData;
        notifyDataSetChanged();
    }
}