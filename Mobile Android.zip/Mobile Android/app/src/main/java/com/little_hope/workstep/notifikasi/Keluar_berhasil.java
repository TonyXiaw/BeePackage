package com.little_hope.workstep.notifikasi;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

import com.little_hope.workstep.R;

public class Keluar_berhasil extends AppCompatActivity {
    Button keluar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keluar_berhasil);
        keluar=findViewById(R.id.btnKeluar);
        keluar.setOnClickListener(view -> {
            finishAffinity();
            System.exit(0);
        });
    }
}