package com.little_hope.workstep;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.little_hope.workstep.adapter.JobdeskAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class Jobdesk extends AppCompatActivity implements JobdeskAdapter.OnFileSelectListener {
    private static final int PICK_PDF_REQUEST = 1;
    private int selectedPosition = -1;
    private Uri fileUri;
    private String pdfBase64 = "";
    ImageView home, projek, keluar;
    TextView nama;
    RequestQueue requestQueue;
    JobdeskAdapter adapter;
    StringRequest stringRequest;
    ArrayList<HashMap<String, String>> arrayList = new ArrayList<>();


    @Override
    public void onFileSelect(int position) {
        selectedPosition = position;
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/pdf");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(intent, "Pilih File PDF"), PICK_PDF_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PDF_REQUEST && resultCode == RESULT_OK && data != null) {
            fileUri = data.getData();
            String fileName = getFileName(fileUri);

            if (selectedPosition >= 0 && selectedPosition < arrayList.size()) {
                arrayList.get(selectedPosition).put("fileName", fileName);
                adapter.notifyItemChanged(selectedPosition);
                convertPdfToBase64();
            } else {
                Toast.makeText(this, "Posisi tidak valid", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void convertPdfToBase64() {
        try {
            InputStream inputStream = getContentResolver().openInputStream(fileUri);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead;

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            pdfBase64 = Base64.encodeToString(outputStream.toByteArray(), Base64.DEFAULT);
            inputStream.close();
            outputStream.close();
            Toast.makeText(this, "File siap diunggah!", Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Gagal mengonversi file!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onFileUpload(int position) {
        if (pdfBase64.isEmpty()) {
            Toast.makeText(this, "Pilih file terlebih dahulu sebelum mengunggah!", Toast.LENGTH_SHORT).show();
        } else {
            // Ambil data dari item yang sedang dipilih
            HashMap<String, String> selectedItem = arrayList.get(position);

            // Simpan ke ConnectDB sebelum dikirim
            ConnectDB.namaJd = selectedItem.get("nama_client");
            ConnectDB.idJd = Integer.parseInt(Objects.requireNonNull(selectedItem.get("id_jobdesk")));

            Log.d("UPLOAD", "Mengupload untuk: " + ConnectDB.namaJd + ", ID: " + ConnectDB.idJd);

            konekDB("upload");
        }
    }


    @SuppressLint("Range")
    private String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            }
        }
        return result != null ? result : uri.getPath();
    }

    private void konekDB(String aksi) {
        stringRequest = new StringRequest(Request.Method.POST,
                ((ConnectDB) getApplication()).getURL() + "jobdesk.php",
                response -> {
                    Log.d("JobdeskResponse", response); // Menampilkan respons dari server di Logcat

                    try {
                        JSONObject jObj = new JSONObject(response);
                        boolean hasil = jObj.optBoolean("hasil", false);
                        String pesan = jObj.optString("pesan", "Tidak ada pesan dari server");

                        // Tampilkan pesan dari server
                        Toast.makeText(this, pesan, Toast.LENGTH_LONG).show();

                        if (!hasil) {
                            // Jika hasilnya false, tampilkan pesan error dan STOP
                            Log.e("UPLOAD_ERROR", "Upload gagal: " + pesan);
                            return; // Mencegah eksekusi lebih lanjut
                        }

                        if (aksi.equalsIgnoreCase("jobdesk")) {
                            arrayList.clear(); // Bersihkan list sebelum menambahkan data baru

                            if (jObj.has("resDataJobDesk")) {
                                JSONArray tasksArray = jObj.optJSONArray("resDataJobDesk");
                                if (tasksArray != null && tasksArray.length() > 0) {
                                    for (int a = 0; a < tasksArray.length(); a++) {
                                        JSONObject json = tasksArray.getJSONObject(a);
                                        HashMap<String, String> map = new HashMap<>();
                                        map.put("nama_client", json.optString("nama_client", "Tidak diketahui"));
                                        map.put("deskripsi", json.optString("deskripsi", "Tidak ada deskripsi"));
                                        map.put("id_jobdesk", json.optString("id_jobdesk", "0"));
                                        arrayList.add(map);
                                    }
                                } else {
                                    Toast.makeText(getApplicationContext(), "Jobdesk sedang tidak ada", Toast.LENGTH_LONG).show();
                                }
                            } else {
                                Toast.makeText(getApplicationContext(), "Data jobdesk tidak tersedia", Toast.LENGTH_LONG).show();
                            }

                            adapter.notifyDataSetChanged();
                        } else if (aksi.equalsIgnoreCase("upload")) {
                            // Jika upload sukses, refresh jobdesk
                            if (hasil) {
                                konekDB("jobdesk");
                            }
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), "Parsing error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    Log.e("UPLOAD_ERROR", "Gagal menghubungi server: " + error.getMessage());
                    Toast.makeText(getApplicationContext(), "Gagal menghubungi server: " + error.getMessage(), Toast.LENGTH_LONG).show();
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> param = new HashMap<>();
                param.put("aksi", aksi);

                if (aksi.equalsIgnoreCase("jobdesk")) {
                    param.put("id_pekerja", String.valueOf(ConnectDB.idpekerja));
                } else if (aksi.equalsIgnoreCase("upload")) {
                    param.put("id_jobdesk", String.valueOf(ConnectDB.idJd));
                    param.put("id_pekerja", String.valueOf(ConnectDB.idpekerja));
                    param.put("tugas", pdfBase64);
                    param.put("nama_client", ConnectDB.namaJd);
                    param.put("nama", ConnectDB.nama);
                    param.put("status", "diambil");
                }
                return param;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                20000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jobdesk);

        home = findViewById(R.id.txtBeranda);
        nama = findViewById(R.id.txtNamaJd);
        projek = findViewById(R.id.btnProjekJd);
        keluar = findViewById(R.id.btnKeluarJd);

        RecyclerView recyclerView = findViewById(R.id.rvJobDesk);
        adapter = new JobdeskAdapter(this
                ,arrayList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        nama.setText(ConnectDB.nama);
        konekDB("jobdesk");

        keluar.setOnClickListener(view -> {
            finishAffinity();
            startActivity(new Intent(getApplicationContext(), Keluar.class));
        });

        home.setOnClickListener(view -> {
            Intent intent = new Intent(Jobdesk.this, MainActivity.class);
            startActivity(intent);
        });

        projek.setOnClickListener(view -> {
            Intent intent = new Intent(Jobdesk.this, Proyek.class);
            startActivity(intent);
        });
    }
}

