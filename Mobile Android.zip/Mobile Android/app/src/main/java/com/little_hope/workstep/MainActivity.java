package com.little_hope.workstep;

import androidx.appcompat.app.AppCompatActivity;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.little_hope.workstep.adapter.TaskAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    TextView nama,kampus,jurusan,totalScore,txtJudulTask,score,kesulitan,keterangan;
    ImageView keluar,proyek,search,jobdesk;
    RequestQueue requestQueue;
    EditText searchInput;
    TaskAdapter adapter;
    StringRequest stringRequest;
    private int searchClickCount = 0;
    ArrayList<HashMap<String, String>> arrayList = new ArrayList<>();
    ArrayList<HashMap<String, String>> arrayListket = new ArrayList<>();

    private void filterData(String keyword) {
        ArrayList<HashMap<String, String>> filteredList = new ArrayList<>();

        for (HashMap<String, String> map : arrayList) {
            String taskName = map.get("nama_task");
            assert taskName != null;
            if (taskName.toLowerCase().contains(keyword.toLowerCase())) {
                filteredList.add(map);
            }
        }

        adapter.updateData(filteredList);
    }
    private void konekDB(String aksi) {
        StringBuilder keteranganText = new StringBuilder();

        stringRequest = new StringRequest(Request.Method.POST,
                ((ConnectDB) getApplication()).getURL() + "task.php",
                response -> {
                    Log.d("LoginResponse", response); // Log response untuk debugging
                    try {
                        JSONObject jObj = new JSONObject(response);
                        String pesan = jObj.optString("pesan", "Tidak ada pesan dari server.");
                        boolean hasil = jObj.optBoolean("hasil", false);
                        Toast.makeText(getApplicationContext(), pesan, Toast.LENGTH_LONG).show();

                        if (hasil) {
                            if (aksi.equalsIgnoreCase("task")) {
                                arrayList.clear(); // Pastikan list dikosongkan sebelum ditambahkan data baru
                                arrayListket.clear(); // Kosongkan juga array list keterangan

                                JSONArray jsonArray = jObj.optJSONArray("resDataTask");
                                if (jsonArray != null && jsonArray.length() > 0) {
                                    for (int a = 0; a < jsonArray.length(); a++) {
                                        JSONObject json = jsonArray.getJSONObject(a);
                                        HashMap<String, String> map = new HashMap<>();
                                        map.put("nama_task", json.optString("nama_task", "Tidak diketahui"));
                                        map.put("score", json.optString("score", "0"));
                                        map.put("tingkat", json.optString("tingkat", "-"));
                                        map.put("description", json.optString("description", "Deskripsi tidak tersedia"));
                                        arrayList.add(map);
                                    }
                                } else {
                                    Toast.makeText(getApplicationContext(), "Tidak ada data tugas.", Toast.LENGTH_LONG).show();
                                }

                                JSONArray jsonArray2 = jObj.optJSONArray("resDataKet");
                                if (jsonArray2 != null && jsonArray2.length() > 0) {
                                    for (int a = 0; a < jsonArray2.length(); a++) {
                                        JSONObject json = jsonArray2.getJSONObject(a);
                                        HashMap<String, String> map = new HashMap<>();
                                        map.put("nama_task2", json.optString("nama_task2", "Tidak ada nama task"));
                                        arrayListket.add(map);

                                        if (a != 0) {
                                            keteranganText.append(", ");  // Tambahkan koma sebagai pemisah
                                        }
                                        keteranganText.append(arrayListket.get(a).get("nama_task2"));
                                    }
                                } else {
                                    keteranganText.append("Tidak ada task sedang dinilai.");
                                }

                                int totalScores = jObj.optInt("total_score", 0);
                                ConnectDB.totalscoreTask = totalScores; // Simpan total score di ConnectDB
                                Log.d("MainActivity", "ArrayListKet size: " + arrayListket.size());
                                Log.d("MainActivity", "Jumlah data di arrayList: " + arrayList.size());

                                adapter.notifyDataSetChanged();
                                keterangan.setText(keteranganText.toString());
                                totalScore.setText(String.valueOf(totalScores));
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), "Parsing error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                },
                error -> Toast.makeText(getApplicationContext(), "Gagal menghubungi server: " + error.getMessage(), Toast.LENGTH_LONG).show()) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> param = new HashMap<>();
                param.put("aksi", aksi);
                param.put("nama_pekerja", ConnectDB.nama);
                param.put("nama_task", ConnectDB.judul_task);
                return param;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recycleView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this)); // Tambahkan ini
        adapter = new TaskAdapter(this, arrayList);
        recyclerView.setAdapter(adapter);


        nama=findViewById(R.id.txtName);
        kampus=findViewById(R.id.txtUniversity);
        keluar=findViewById(R.id.btnLogout);
        jurusan=findViewById(R.id.txtStudy);
        score=findViewById(R.id.txtScore);
        totalScore=findViewById(R.id.txtTotalScores);
        txtJudulTask=findViewById(R.id.txtJudulTask);
        kesulitan=findViewById(R.id.txtKesulitan);
        proyek=findViewById(R.id.btnProyek);
        search=findViewById(R.id.btnSearch);
        searchInput=findViewById(R.id.searchInput);
        jobdesk=findViewById(R.id.btnJobdesk);
        keterangan=findViewById(R.id.txtKeterangan);

        nama.setText(ConnectDB.nama);
        kampus.setText(ConnectDB.universitas);
        jurusan.setText(ConnectDB.jurusan);


        konekDB("task");

        keluar.setOnClickListener(view -> {
            finishAffinity();
            startActivity(new Intent(getApplicationContext(), Keluar.class));
        });
        proyek.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, Proyek.class);
            startActivity(intent);
        });
        jobdesk.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, Jobdesk.class);
            startActivity(intent);
        });

        search.setOnClickListener(v -> {
            searchClickCount++;

            if (searchClickCount == 1) {
                searchInput.setVisibility(View.VISIBLE);
            } else if (searchClickCount == 2) {
                searchInput.setVisibility(View.GONE);
                searchClickCount = 0;
            }

            // Reset klik jika tidak diklik lagi dalam 0.5 detik
            search.postDelayed(() -> searchClickCount = 0, 500);
        });

        // Filter saat mengetik
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterData(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

}