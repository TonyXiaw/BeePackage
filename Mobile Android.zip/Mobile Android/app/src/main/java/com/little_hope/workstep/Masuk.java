package com.little_hope.workstep;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.little_hope.workstep.notifikasi.LupaPassword;
import com.little_hope.workstep.notifikasi.Masuk_berhasil;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Masuk extends AppCompatActivity {
    TextView daftar,emailMasuk,passMasuk,lupapassword;
    Button masuk;

    RequestQueue requestQueue;
    StringRequest stringRequest;
    ArrayList<HashMap<String, String>> arrayList = new ArrayList<>();

    private void konekDB(String aksi){
        //akhir onResponse
        stringRequest = new StringRequest(Request.Method.POST,
                ((ConnectDB) getApplication()).getURL() + "login.php",
                response -> {
                    Log.d("LoginResponse", response); // Log response untuk debugging
                    try {
                        JSONObject jObj = new JSONObject(response);
                        String pesan = jObj.getString("pesan");
                        boolean hasil = jObj.getBoolean("hasil");
                        Toast.makeText(getApplicationContext(), pesan, Toast.LENGTH_LONG).show();
                        if(hasil) {
                            if(aksi.equalsIgnoreCase("login")){
                                JSONArray jsonArray = jObj.getJSONArray("resDataPel");
                                for (int a = 0; a < jsonArray.length(); a++) {
                                    JSONObject json = jsonArray.getJSONObject(a);
                                    HashMap<String, String> map = new HashMap<>();
                                    map.put("id_pekerja", json.getString("id_pekerja"));
                                    map.put("nama", json.getString("nama"));
                                    map.put("universitas", json.getString("universitas"));
                                    map.put("jurusan", json.getString("jurusan"));
                                    map.put("email", json.getString("email"));
                                    arrayList.add(map);
                                    ConnectDB.idpekerja =
                                            Integer.valueOf(Objects.requireNonNull(arrayList.get(a).get("id_pekerja")));
                                    ConnectDB.nama =
                                            String.valueOf(arrayList.get(a).get("nama"));
                                    ConnectDB.universitas =
                                            String.valueOf(arrayList.get(a).get("universitas"));
                                    ConnectDB.jurusan =
                                            String.valueOf(arrayList.get(a).get("jurusan"));
                                    ConnectDB.email =
                                            String.valueOf(arrayList.get(a).get("email"));
                                }
                                finishAffinity();
                                startActivity(new Intent(getApplicationContext(), Masuk_berhasil.class));
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }, //akhir Listener
                error -> Toast.makeText(getApplicationContext(), "Gagal menghubungi server : " +
                        error.getMessage(), Toast.LENGTH_LONG).show()) //akhir ErrorListener dan new StringRequest
        {   @Override
        protected Map<String,String> getParams() throws AuthFailureError {
            Map<String, String> param = new HashMap<>();
            if(aksi.equalsIgnoreCase("login"))
                param.put("aksi","login");
            param.put("email", emailMasuk.getText().toString().trim());
            param.put("pass", passMasuk.getText().toString().trim());
            return param;
        }
        }; //akhir stringRequest =
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    } //akhir method konekDB


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_masuk);
        daftar=findViewById(R.id.txtDaftar);
        emailMasuk=findViewById(R.id.txtEmailMasuk);
        passMasuk=findViewById(R.id.txtPasswordMasuk);
        masuk=findViewById(R.id.btnMasuk);
        lupapassword=findViewById(R.id.txtLupa);



        daftar.setOnClickListener(view -> {
            Intent intent=new Intent(getApplicationContext(),Daftar.class);
            startActivity(intent);
            finish();
        });
        masuk.setOnClickListener(view -> {
            if (!emailMasuk.getText().toString().trim().isEmpty()
                    && !Patterns.EMAIL_ADDRESS.matcher(emailMasuk.getText()).matches()) {
                emailMasuk.setError("Formal email salah harusnya email@email.com");
                emailMasuk.requestFocus();

            } else {
                String passwordText = passMasuk.getText().toString();
                String regex = "^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[!@#$%^&*(),.?\":{}|<>]).{8,}$";

                // Membuat Pattern dan Matcher
                Pattern pattern = Pattern.compile(regex);
                Matcher matcher = pattern.matcher(passwordText);

                if (!matcher.matches()) {
                    passMasuk.setError("Password harus mengandung huruf, angka, dan simbol dengan panjang minimal 8 karakter.");
                    passMasuk.requestFocus();
                } else {

                    // Mengirim data ke server
                    konekDB("login");
                }


            }
        });
        lupapassword.setOnClickListener(view -> {
            Intent intent=new Intent(getApplicationContext(), LupaPassword.class);
            startActivity(intent);
        });

    }
}