package com.little_hope.workstep.notifikasi;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.little_hope.workstep.ConnectDB;
import com.little_hope.workstep.Proyek;
import com.little_hope.workstep.R;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;



public class ProyekDetail extends AppCompatActivity {
    TextView namaperusahaan, tanggal, deskripsi, kembali;
    ImageView kembali2, telepon;
    Button ambil;
    RequestQueue requestQueue;
    StringRequest stringRequest;
    private void konekDB(String aksi){
        //akhir onResponse
        stringRequest = new StringRequest(Request.Method.POST,
                ((ConnectDB) getApplication()).getURL() + "ambil_proyek.php",
                response -> {
                    Log.d("LoginResponse", response); // Log response untuk debugging
                    try {
                        JSONObject jObj = new JSONObject(response);
                        String pesan = jObj.getString("pesan");
                        boolean hasil = jObj.getBoolean("hasil");
                        Toast.makeText(getApplicationContext(), pesan, Toast.LENGTH_LONG).show();
                        if(hasil) {
                            if(aksi.equalsIgnoreCase("ambil_proyek")){
                                finishAffinity();
                                startActivity(new Intent(getApplicationContext(), Proyek.class));
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }, //akhir Listener
                error -> Toast.makeText(getApplicationContext(), "Gagal menghubungi server : " +
                        error.getMessage(), Toast.LENGTH_LONG).show()) //akhir ErrorListener dan new StringRequest
        {   @Override
        protected Map<String,String> getParams() throws AuthFailureError {
            Map<String, String> param = new HashMap<>();
            if(aksi.equalsIgnoreCase("ambil_proyek"))
                param.put("aksi","ambil_proyek");
            param.put("id_pekerja", String.valueOf(ConnectDB.idpekerja));
            param.put("nama_pekerja", ConnectDB.nama);
            param.put("perusahaan",ConnectDB.namaPerusahaan);
            param.put("status","diambil");
            param.put("email",ConnectDB.email);

            return param;
        }
        }; //akhir stringRequest =
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    } //akhir method konekDB
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proyek_detail);

        namaperusahaan = findViewById(R.id.txtNamaPerusahaan);
        tanggal = findViewById(R.id.txtTglDetail);
        deskripsi = findViewById(R.id.txtDesDet);
        kembali = findViewById(R.id.btnKembaliDet);
        kembali2 = findViewById(R.id.btnKembaliDet2);
        telepon = findViewById(R.id.btnTelepon);
        ambil=findViewById(R.id.btnAmbilPro);

        namaperusahaan.setText(ConnectDB.namaPerusahaan);
        tanggal.setText(ConnectDB.tanggal);
        deskripsi.setText(ConnectDB.deskripsiProyek);

        kembali.setOnClickListener(view -> startActivity(new Intent(ProyekDetail.this, Proyek.class)));
        kembali2.setOnClickListener(view -> startActivity(new Intent(ProyekDetail.this, Proyek.class)));

        telepon.setOnClickListener(v -> {
            String phoneNumber = ConnectDB.contact;
            Log.d("DEBUG_TEL", "Nomor dari ConnectDB: " + phoneNumber); // Debugging nomor telepon

            if (phoneNumber != null && !phoneNumber.trim().isEmpty()) {
                // Hapus karakter selain angka
                phoneNumber = phoneNumber.replaceAll("[^0-9]", "").trim();

                if (!phoneNumber.isEmpty()) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_DIAL);
                        intent.setData(Uri.parse("tel:" + phoneNumber));

                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "Gagal membuka dialer", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Nomor telepon tidak valid", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getApplicationContext(), "Nomor telepon tidak tersedia", Toast.LENGTH_SHORT).show();
            }
        });

        ambil.setOnClickListener(view -> konekDB("ambil_proyek"));
    }
}
