package com.little_hope.workstep.notifikasi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.little_hope.workstep.MainActivity;
import com.little_hope.workstep.R;


public class Masuk_berhasil extends AppCompatActivity {
    Button ok;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_masuk_berhasil);
        ok=findViewById(R.id.btnOk2);

        ok.setOnClickListener(view -> {
            Intent inten=new Intent(Masuk_berhasil.this, MainActivity.class);
            startActivity(inten);
        });


    }
}