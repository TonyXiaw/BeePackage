package com.little_hope.workstep.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.little_hope.workstep.ConnectDB;
import com.little_hope.workstep.R;

import java.util.ArrayList;
import java.util.HashMap;

public class JobdeskAdapter extends RecyclerView.Adapter<JobdeskAdapter.ViewHolder> {
    private final ArrayList<HashMap<String, String>> listData;
    private final OnFileSelectListener fileSelectListener;
    private final Context context;
    public interface OnFileSelectListener {
        void onFileSelect(int position);
        void onFileUpload(int position);

    }

    public JobdeskAdapter(Context context,ArrayList<HashMap<String, String>> listData, OnFileSelectListener listener) {
        this.listData = listData;
        this.fileSelectListener = listener;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_jobdesk, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        HashMap<String, String> map = listData.get(position);
        holder.txtClientJd.setText(map.get("nama_client"));
        holder.txtDeskripsiJd.setText(map.get("deskripsi"));
        if (holder.txtNamaFile == null) {
            Log.e("AdapterError", "txtNamaFile is NULL at position: " + position);
        }
        String fileName = map.get("fileName");
        if (fileName != null && !fileName.isEmpty()) {
            holder.txtNamaFile.setText(fileName);
        } else {
            holder.txtNamaFile.setText("Belum ada file"); // Teks default jika belum ada file
        }

        // Klik tombol Upload
        holder.btnUploadJd.setOnClickListener(view -> {
            if (ConnectDB.totalscoreTask >= 100) {
                if (fileSelectListener != null) {
                    fileSelectListener.onFileSelect(position);
                }
            }
            else {
                // Tampilkan notifikasi jika score belum cukup
                Toast.makeText(context, "Belum memenuhi syarat! Skor harus 100.", Toast.LENGTH_SHORT).show();
            }
        });
        holder.btnSelesaiJd.setOnClickListener(view -> {
            if (ConnectDB.totalscoreTask >= 100) {
                if (fileSelectListener != null) {
                    fileSelectListener.onFileUpload(position);
                }
            }
            else {
                // Tampilkan notifikasi jika score belum cukup
                Toast.makeText(context, "Belum memenuhi syarat! Skor harus 100.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtClientJd, txtDeskripsiJd, txtNamaFile;
        Button btnUploadJd,btnSelesaiJd;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtClientJd = itemView.findViewById(R.id.txtClientJd);
            txtDeskripsiJd = itemView.findViewById(R.id.txtDeskripsiJd);
            txtNamaFile = itemView.findViewById(R.id.txtNamaFileJd);
            btnUploadJd = itemView.findViewById(R.id.btnUploadJd);
            btnSelesaiJd=itemView.findViewById(R.id. btnSelesaiJd);
        }
    }
}
