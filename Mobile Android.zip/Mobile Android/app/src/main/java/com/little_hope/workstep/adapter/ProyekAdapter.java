package com.little_hope.workstep.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import com.little_hope.workstep.ConnectDB;
import com.little_hope.workstep.R;
import com.little_hope.workstep.notifikasi.ProyekDetail;
import java.util.ArrayList;
import java.util.HashMap;


public class ProyekAdapter extends RecyclerView.Adapter<ProyekAdapter.ViewHolder>{
    private final Context context;
    private ArrayList<HashMap<String, String>> listData;


    public ProyekAdapter(Context context, ArrayList<HashMap<String, String>> listData) {
        this.context = context;
        this.listData = listData;

    }

    @Override
    public ProyekAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_proyek, null);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(ProyekAdapter.ViewHolder holder, int position) {
        HashMap<String, String> item = listData.get(position);
        holder.tvName.setText(item.get("nama_client"));
        holder.tvTgl.setText(item.get("tanggal_proyek"));
        holder.tvDes.setText(item.get("deskripsi_proyek"));


        holder.itemView.setOnClickListener(v -> {
           if (ConnectDB.totalscoreTask >= 100) { // Pastikan nilai score sudah 100
                // Simpan data ke ConnectDB
                ConnectDB.namaPerusahaan = item.get("nama_client");
                ConnectDB.tanggal = item.get("tanggal_proyek");
                ConnectDB.deskripsiProyek = item.get("deskripsi_proyek");
                ConnectDB.contact = item.get("contact");

                // Pindah ke TaskDetail
                Intent intent = new Intent(context, ProyekDetail.class);
                context.startActivity(intent);
           } else {
                // Tampilkan notifikasi jika score belum cukup
                Toast.makeText(context, "Belum memenuhi syarat! Skor harus 100.", Toast.LENGTH_SHORT).show();
            }
        });
        holder.btnAmbilProyek.setOnClickListener(view -> {
            if (ConnectDB.totalscoreTask >= 100) { // Pastikan nilai score sudah 100
                // Simpan data ke ConnectDB
                ConnectDB.namaPerusahaan = item.get("nama_client");
                ConnectDB.tanggal = item.get("tanggal_proyek");
                ConnectDB.deskripsiProyek = item.get("deskripsi_proyek");
                ConnectDB.contact = item.get("contact");

                // Pindah ke TaskDetail
                Intent intent = new Intent(context, ProyekDetail.class);
                context.startActivity(intent);
            } else {
                // Tampilkan notifikasi jika score belum cukup
                Toast.makeText(context, "Belum memenuhi syarat! Skor harus 100.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName,tvTgl,tvDes;
        Button btnAmbilProyek;
        public ViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.txtClient);
            tvTgl = itemView.findViewById(R.id.txtTgl);
            tvDes = itemView.findViewById(R.id.textDes);
            btnAmbilProyek=itemView.findViewById(R.id.btnAmbilProyek);
        }
    }
    public void updateData(ArrayList<HashMap<String, String>> newData) {
        this.listData = newData;
        notifyDataSetChanged();
    }
}
