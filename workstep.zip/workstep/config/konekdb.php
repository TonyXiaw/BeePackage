<?php
 $my['host']="localhost";
 $my['user']="root";
 $my['pass']="";
 $my['dbs']="workstep";

 $koneksi=mysqli_connect(
 $my['host'],
 $my['user'],
 $my['pass']);
 
 if(!$koneksi){
     echo "Koneksi ke database gagal !";
     mysqli_error($koneksi);
 }
 mysqli_select_db($koneksi, $my["dbs"]) or die("Database tidak ada ".mysqli_error($koneksi));






?>