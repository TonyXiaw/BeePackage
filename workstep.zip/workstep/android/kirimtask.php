<?php
include '../config/konekdb.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST["aksi"] == "kirimtask") {
    $nama_task = strtoupper($_POST["nama_task"]);
    $nama = strtoupper($_POST["nama"]);
    $score=strtoupper($_POST["score"]);
    $tugas = mysqli_real_escape_string($koneksi, $_POST["tugas"]);
    $status = $_POST["status"];

    // **Update data di tabel `task`**
    $queryUpdateTask = "UPDATE task SET status='belum dipilih'  WHERE nama_task = '$nama_task'";

    if (mysqli_query($koneksi, $queryUpdateTask)) {
        // **Jika update berhasil, masukkan ke tabel `ambil_task`**
        $queryInsertAmbilTask = "INSERT INTO ambil_task (nama_task, nama_pekerja, tugas, status,score) 
                                 VALUES ('$nama_task','$nama', '$tugas', '$status',$score)";

        if (mysqli_query($koneksi, $queryInsertAmbilTask)) {
            $response['hasil'] = true;
            $response['pesan'] = "Task berhasil dikirim dan dicatat dalam ambil_task.";
        } else {
            $error_message = mysqli_error($koneksi);
            $response['hasil'] = false;
            $response['pesan'] = "Update task berhasil, tapi gagal menyimpan ke ambil_task! Error: $error_message";
        }
    } else {
        $error_message = mysqli_error($koneksi);
        $response['hasil'] = false;
        $response['pesan'] = "Terjadi kesalahan saat mengupdate task. Error: $error_message";
    }
} else {
    $response['hasil'] = false;
    $response['pesan'] = "Ada kesalahan, mohon hubungi administrator.";
}

echo json_encode($response);
mysqli_close($koneksi);
?>

