<?php
include '../config/konekDB.php';

header('Content-Type: application/json');

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["aksi"])) {
    $aksi = $_POST["aksi"];

    if ($aksi == "jobdesk") {  // Jika user ingin mengambil daftar jobdesk
        $json_response = array();
        $id_pekerja = strtoupper($_POST["id_pekerja"]);

        $qCekPel = mysqli_query($koneksi, 
        "SELECT
        A.nama_client, 
        A.deskripsi, 
        A.id_jobdesk
        FROM jobdesk A
        WHERE A.status = 'belum diambil'
        AND NOT EXISTS (
            SELECT 1 FROM ambil_jobdesk B
            WHERE B.id_jobdesk = A.id_jobdesk 
            AND B.id_pekerja = '$id_pekerja'
            AND B.status <> 'gagal'
        )")
        or die(json_encode(["hasil" => false, "pesan" => "SQL Error: " . mysqli_error($koneksi)]));
        
        if (mysqli_num_rows($qCekPel) == 0) {
            $response['hasil'] = false;
            $response['pesan'] = "Job sudah pernah diambil atau tidak tersedia";
        } else {
            while ($row = mysqli_fetch_assoc($qCekPel)) {
                $json_response[] = $row;
            }
            $response['hasil'] = true;
            $response['pesan'] = "Data jobdesk berhasil diambil";
            $response['resDataJobDesk'] = $json_response;
        }
    } elseif ($aksi == "upload") {  
        if (!isset($_POST["id_pekerja"]) || !isset($_POST["tugas"]) || !isset($_POST["nama_client"]) || !isset($_POST["id_jobdesk"])) {
            $response['hasil'] = false;
            $response['pesan'] = "Data tidak lengkap!";
            echo json_encode($response);
            exit();
        }
    
        $id_jobdesk = strtoupper($_POST["id_jobdesk"]);
        $nama = strtoupper($_POST["nama"]);
        $id_pekerja = strtoupper($_POST["id_pekerja"]);
        $tugas = $_POST["tugas"];
        $nama_client = strtoupper($_POST["nama_client"]);
        $status = strtoupper($_POST["status"]);
    
        if (empty($status)) {
            $status = 'belum dinilai';
        }
    
        // 🔍 Cek apakah pekerja sudah gagal pada jobdesk ini
        $queryCekGagal = "SELECT * FROM ambil_jobdesk WHERE id_jobdesk = '$id_jobdesk' AND id_pekerja = '$id_pekerja' AND status = 'gagal'";
        $resultCekGagal = mysqli_query($koneksi, $queryCekGagal);
    
        if (mysqli_num_rows($resultCekGagal) > 0) {
            $response['hasil'] = false;
            $response['pesan'] = "$nama tidak dapat mengupload tugas ini karena sudah dianggap gagal sebelumnya!";
        } else {
            // Update data tugas ke database
            $query = "UPDATE jobdesk SET status='belum diambil' WHERE id_jobdesk='$id_jobdesk'";
    
            if (mysqli_query($koneksi, $query)) {
                // Jika update berhasil, masukkan ke tabel `ambil_jobdesk`
                $queryInsertAmbilProyek = "INSERT INTO ambil_jobdesk (id_jobdesk, id_pekerja, nama_pekerja, tugas, status) 
                VALUES ('$id_jobdesk', '$id_pekerja', '$nama', '$tugas', '$status')" ;
    
                if (mysqli_query($koneksi, $queryInsertAmbilProyek)) {
                    $response['hasil'] = true;
                    $response['pesan'] = "Task berhasil dikirim dan dicatat dalam ambil_jobdesk.";
                } else {
                    $error_message = mysqli_error($koneksi);
                    $response['hasil'] = false;
                    $response['pesan'] = "Update task berhasil, tapi gagal menyimpan ke ambil_jobdesk! Error: $error_message";
                }
            } else {
                $error_message = mysqli_error($koneksi);
                $response['hasil'] = false;
                $response['pesan'] = "Terjadi kesalahan saat mengupdate task. Error: $error_message";
            }
        }    
    } else {
        $response['hasil'] = false;
        $response['pesan'] = "Aksi tidak valid!";
    }
} else {
    $response['hasil'] = false;
    $response['pesan'] = "Metode request tidak valid!";
}

echo json_encode($response, JSON_PRETTY_PRINT);
mysqli_close($koneksi);
?>
