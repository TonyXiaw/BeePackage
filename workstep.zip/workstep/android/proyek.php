<?php
	include '../config/konekDB.php';
	if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["aksi"]) && $_POST["aksi"] == "proyek")  {
		$json_response = array();
		//buat semua UPPERCASE (misal username yang tidak case sensitive)
		
		$qCekPel = mysqli_query($koneksi,"SELECT * FROM proyek") or die(mysqli_error($koneksi));
		if (mysqli_num_rows($qCekPel)==0){
	      	$response['hasil'] = false;
	  		$response['pesan'] = "Tidak ada proyek yang tersedia";
	  		echo json_encode($response);
	 	} else {
            // Jika data ditemukan, ambil data pekerja
            while ($row = mysqli_fetch_array($qCekPel)) {
                $json_response[] = array(
                    'nama_client' => $row["nama_client"],
					'tanggal_proyek' => $row["tanggal_proyek"],
					'deskripsi_proyek' => $row["deskripsi_proyek"],
					'contact'=>$row["contact"],
                );
            }

            // Kirimkan respons sukses dengan data pekerja
            $response = array(
                'hasil' => true,
                //`'pesan' =>'',
                'resDataProyek' => $json_response
            );
		}	
            echo json_encode($response);	
	} //akhir aksi login
	else {
	  $response['hasil']= false ;
	  $response['pesan']="Ada kesalahan, mohon hubungi administrator sistem";
	  echo json_encode($response);
	}
	mysqli_close($koneksi);			
?>	