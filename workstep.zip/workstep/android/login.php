<?php
	include '../config/konekDB.php';
	if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["aksi"]) && $_POST["aksi"] == "login")  {
		$json_response = array();
		//buat semua UPPERCASE (misal username yang tidak case sensitive)
		$email = strtoupper($_POST["email"]);
		$pass = sha1($_POST["pass"]);
		$qCekPel = mysqli_query($koneksi,"SELECT * FROM dtpekerja WHERE email='".$email."' AND password='".$pass."'") or die(mysqli_error($koneksi));
		if (mysqli_num_rows($qCekPel)==0){
	      	$response['hasil'] = false;
	  		$response['pesan'] = "Email atau password yang dimasukkan tidak sesuai!";
	  		echo json_encode($response);
	 	} else {
            // Jika data ditemukan, ambil data pekerja
            while ($row = mysqli_fetch_array($qCekPel)) {
                $json_response[] = array(
                    'id_pekerja' => $row["id_pekerja"],
					'nama' => $row["nama"],
					'universitas' => $row["universitas"],
					'jurusan' => $row["jurusan"],
                    'email' => $row["email"]
                );
            }

            // Kirimkan respons sukses dengan data pekerja
            $response = array(
                'hasil' => true,
                'pesan' => 'Login sucess',
                'resDataPel' => $json_response
            );
		}	
            echo json_encode($response);	
	} //akhir aksi login
	else {
	  $response['hasil']= false ;
	  $response['pesan']="Ada kesalahan, mohon hubungi administrator sistem";
	  echo json_encode($response);
	}
	mysqli_close($koneksi);			
?>	