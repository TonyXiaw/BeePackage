<?php
include '../config/konekDB.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["aksi"]) && $_POST["aksi"] == "task") {
    $nama_task = strtoupper($_POST["nama_task"]);
    $nama_pekerja = strtoupper($_POST["nama_pekerja"]);

    $json_response = array();
    $json_response2 = array();
    $total_score = 0; // Inisialisasi total score

    // Query untuk mendapatkan semua task yang statusnya belum dipilih atau gagal
   // $qCekPel = mysqli_query($koneksi, "SELECT * FROM task WHERE status='belum dipilih' OR status='gagal'") or die(mysqli_error($koneksi));
   $nama_pekerja = strtoupper($_POST["nama_pekerja"]);

   $qCekPel = mysqli_query($koneksi, 
   "SELECT 
       t.nama_task, 
       t.tingkat, 
       t.description, 
       t.score
   FROM task t
   WHERE 
       -- Ambil hanya tugas dengan status 'belum dipilih' atau 'gagal'
       (t.status = 'belum dipilih' OR t.status = 'gagal')
   
       -- Abaikan tugas yang sudah diambil oleh pekerja ini (tapi tidak peduli pekerja lain)
       AND NOT EXISTS (
           SELECT 1 FROM ambil_task at2
           WHERE at2.nama_task = t.nama_task
           AND at2.nama_pekerja = '$nama_pekerja'
       )
   ") or die(json_encode(["hasil" => false, "pesan" => "SQL Error: " . mysqli_error($koneksi)]));
   
   

    while ($row = mysqli_fetch_array($qCekPel)) {
        $json_response[] = array(
            'nama_task' => $row["nama_task"],
            'tingkat' => $row["tingkat"],
            'score' => $row["score"],
            'description' => $row["description"],
            //'status' => $row["status"]
        );
    }

    // Query untuk mendapatkan task dengan status 'sedang dinilai'
    $qCekPel2 = mysqli_query($koneksi, "SELECT * FROM ambil_task WHERE status='sedang dinilai' 
    AND nama_pekerja='$nama_pekerja' ") or die(mysqli_error($koneksi));

    while ($row2 = mysqli_fetch_array($qCekPel2)) {
        $json_response2[] = array(
            'nama_task2' => $row2["nama_task"]
        );
    }

    // **Ambil total score dengan filter nama_pekerja jika diberikan**
    $queryScore = "SELECT SUM(score) AS total_score FROM ambil_task WHERE status='berhasil'";
    if ($nama_pekerja) {
        $queryScore .= " AND nama_pekerja='$nama_pekerja'"; 
    }

    $qCekPel3 = mysqli_query($koneksi, $queryScore) or die(mysqli_error($koneksi));
    $row3 = mysqli_fetch_array($qCekPel3);
    $total_score = (int) ($row3["total_score"] ?? 0);

    // Set hasil berdasarkan apakah ada data atau tidak
    $response['hasil'] = true;
    $response['pesan'] = 'Data score berhasil diambil';
    $response['total_score'] = $total_score; // **Total score tetap ada**
    $response['resDataTask'] = $json_response;
    $response['resDataKet'] = $json_response2;

    // Kirimkan respons dalam format JSON
    echo json_encode($response);
} else {
    $response['hasil'] = false;
    $response['pesan'] = "Ada kesalahan, mohon hubungi administrator sistem";
    echo json_encode($response);
}

mysqli_close($koneksi);
