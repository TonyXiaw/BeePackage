<?php
    include '../config/konekdb.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST["aksi"] == "ambil_proyek") {
        $nama_pekerja = $_POST["nama_pekerja"];
        $id_pekerja = $_POST["id_pekerja"];
        $perusahaan = $_POST["perusahaan"];
        $status = $_POST["status"];
        $email = $_POST["email"];

        // Cek apakah pekerja sudah mengambil proyek dengan status "gagal"
        $check_gagal_query = "SELECT * FROM ambil_proyek WHERE id_pekerja = '$id_pekerja' AND perusahaan = '$perusahaan' AND status = 'gagal'";
        $result_gagal = mysqli_query($koneksi, $check_gagal_query);

        if (mysqli_num_rows($result_gagal) > 0) {
            // Jika sudah gagal sebelumnya, kirim pesan bahwa pekerja telah gagal
            $response['hasil'] = false;
            $response['pesan'] = "Maaf $nama_pekerja anda sudah gagal menjalani tes ini";
            echo json_encode($response);
        } else {
            // Cek apakah pekerja sudah mengambil proyek yang sama sebelumnya (tanpa status 'gagal')
            $check_query = "SELECT * FROM ambil_proyek WHERE id_pekerja = '$id_pekerja' AND perusahaan = '$perusahaan'";
            $result = mysqli_query($koneksi, $check_query);

            if (mysqli_num_rows($result) > 0) {
                // Jika sudah mengambil proyek sebelumnya (bukan gagal), kirim pesan
                $response['hasil'] = false;
                $response['pesan'] = "Maaf $nama_pekerja sudah ambil proyek perusahaan $perusahaan ini.";
                echo json_encode($response);
            } else {
                // Jika belum pernah mengambil proyek, lakukan insert
                $query = "INSERT INTO ambil_proyek(nama_pekerja, id_pekerja, perusahaan, status, email)
                          VALUES ('$nama_pekerja', '$id_pekerja', '$perusahaan', '$status', '$email')";

                if (mysqli_query($koneksi, $query)) {
                    $response['hasil'] = true;
                    $response['pesan'] = "Proyek dari perusahaan $perusahaan telah diambil, mohon menunggu panggilan!";
                    echo json_encode($response);
                } else {
                    $error_message = mysqli_error($koneksi);
                    $response['hasil'] = false;
                    $response['pesan'] = "Terjadi kesalahan saat mengambil proyek! $error_message";
                    echo json_encode($response);
                }
            }
        }
        
    } else {
        $response['hasil'] = false;
        $response['pesan'] = "Ada kesalahan, mohon hubungi Admin";
        echo json_encode($response);
    }

    mysqli_close($koneksi);
?>
