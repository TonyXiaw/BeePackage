<?php
include '../config/konekDB.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["aksi"]) && $_POST["aksi"] == "jobdesk") {
    $id_pekerja = strtoupper($_POST["id_pekerja"]);
    $tugas = $_POST["tugas"]; // Data tugas mungkin Base64, tidak perlu strtoupper
    $nama_client = strtoupper($_POST["nama_client"]);

    // Ambil daftar jobdesk
    $json_response = array();
    $qCekPel = mysqli_query($koneksi, "SELECT * FROM jobdesk") or die(mysqli_error($koneksi));

    if (mysqli_num_rows($qCekPel) == 0) {
        $response['hasil'] = false;
        $response['pesan'] = "Tidak ada jobdesk yang tersedia";
    } else {
        while ($row = mysqli_fetch_array($qCekPel)) {
            $json_response[] = array(
                'nama_client' => $row["nama_client"],
                'deskripsi' => $row["deskripsi"]
            );
        }
    }
    $response = array(
        'hasil' => true,
        'pesan' =>'koneksi ok',
        'resDataProyek' => $json_response
    );
    
    // Update data tugas ke database
    $query = "UPDATE jobdesk SET tugas='$tugas', id_pekerja='$id_pekerja' WHERE nama_client = '$nama_client'";

    if (mysqli_query($koneksi, $query)) {
        $response['hasil'] = true;
        $response['pesan'] = "Pekerjaan berhasil dikirim";
    } else {
        $response['hasil'] = false;
        $response['pesan'] = "Terjadi kesalahan saat mengirim: " . mysqli_error($koneksi);
    }

    // Gabungkan data jobdesk dengan respons utama
    $response['resDataJobDesk'] = $json_response;
} else {
    $response['hasil'] = false;
    $response['pesan'] = "Ada kesalahan, mohon hubungi administrator sistem";
}

// Kirimkan respons dalam format JSON
echo json_encode($response);

// Tutup koneksi database
mysqli_close($koneksi);
