<?php
    include '../config/konekdb.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST["aksi"] == "daftar") {
        $nama = $_POST["nama"];
        $hp = $_POST["hp"];
        $usia = $_POST["usia"];
        $gender = $_POST["gender"];
        $kampus = $_POST["kampus"];
        $jurusan = $_POST["jurusan"];
        $email = $_POST["email"];
        $pass = sha1($_POST["pass"]);

        // Mengecek apakah nomor HP sudah terdaftar
        $qcek_hp = mysqli_query($koneksi, "SELECT * FROM dtpekerja WHERE no_hp = '$hp'") or die(mysqli_error($koneksi));
        if (mysqli_num_rows($qcek_hp) > 0) {
            $response['hasil'] = false;
            $response['pesan'] = "Pekerja dengan no HP $hp sudah pernah mendaftar!";
            echo json_encode($response);
            exit(); // Stop eksekusi script jika HP sudah terdaftar
        }

        // Mengecek apakah email sudah terdaftar
        $qcek_email = mysqli_query($koneksi, "SELECT * FROM dtpekerja WHERE email = '$email'") or die(mysqli_error($koneksi));
        if (mysqli_num_rows($qcek_email) > 0) {
            $response['hasil'] = false;
            $response['pesan'] = "Email $email sudah digunakan, silakan gunakan email lain!";
            echo json_encode($response);
            exit(); // Stop eksekusi script jika email sudah terdaftar
        }

        // Melakukan proses pendaftaran jika tidak ada data yang duplikat
        $query = "INSERT INTO dtpekerja(nama, jenkel, usia, universitas, jurusan, no_hp, email, password)
                  VALUES ('$nama', '$gender', '$usia', '$kampus', '$jurusan', '$hp', '$email', '$pass')";

        if (mysqli_query($koneksi, $query)) {
            $response['hasil'] = true;
            $response['pesan'] = "Pendaftaran berhasil!";
            echo json_encode($response);
        } else {
            $error_message = mysqli_error($koneksi);
            $response['hasil'] = false;
            $response['pesan'] = "Terjadi kesalahan saat mendaftar. Silakan coba lagi! $error_message";
            echo json_encode($response);
        }
    } else {
        $response['hasil'] = false;
        $response['pesan'] = "Ada Kesalahan, Mohon Hubungi Admin";
        echo json_encode($response);
    }

    mysqli_close($koneksi);
?>
