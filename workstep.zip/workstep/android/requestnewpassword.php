<?php
include '../config/konekDB.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["aksi"])) {
    $aksi = $_POST["aksi"];
    $email = $_POST["email"];

    if ($aksi == "email") {
        // Periksa apakah email terdaftar
        $cek_email = mysqli_query($koneksi, "SELECT * FROM dtpekerja WHERE email = '$email'");
        
        if (mysqli_num_rows($cek_email) > 0) {
            // Generate kode acak (OTP)
            $code = rand(100000, 999999); // 6 digit angka acak

            // Simpan kode OTP ke database
            $update_query = "INSERT INTO requestcode (email, code) 
                VALUES ('$email', '$code') 
                ON DUPLICATE KEY UPDATE code = '$code'";

            if (mysqli_query($koneksi, $update_query)) {
                // Kirim kode OTP ke email pengguna
                $subject = "Kode Verifikasi Reset Password";
                $message = "Kode verifikasi Anda adalah: $code";
                $headers = "From: no-reply@yourdomain.com";

                if (mail($email, $subject, $message, $headers)) {
                    $response['hasil'] = true;
                    $response['pesan'] = "Kode verifikasi telah dikirim ke email Anda.";
                } else {
                    $response['hasil'] = false;
                    $response['pesan'] = "Gagal mengirim email.";
                }
            } else {
                $response['hasil'] = false;
                $response['pesan'] = "Gagal menyimpan kode verifikasi.";
            }
        } else {
            $response['hasil'] = false;
            $response['pesan'] = "Email tidak terdaftar.";
        }
    } elseif ($aksi == "verifikasi") {
        // Menerima kode OTP dan password baru
        $code = $_POST["code"];
        $new_password = sha1($_POST["pass"]); // Enkripsi password

        // Periksa apakah kode OTP valid
        $cek_code = mysqli_query($koneksi, "SELECT * FROM requestcode WHERE email = '$email' AND code = '$code'");

        if (mysqli_num_rows($cek_code) > 0) {
            // Update password pengguna
            $update_pass = mysqli_query($koneksi, "UPDATE dtpekerja SET password = '$new_password' WHERE email = '$email'");

            if ($update_pass) {
                // Hapus kode OTP setelah digunakan
                mysqli_query($koneksi, "DELETE FROM requestcode WHERE email = '$email'");

                $response['hasil'] = true;
                $response['pesan'] = "Password berhasil diubah. Silakan login dengan password baru.";
            } else {
                $response['hasil'] = false;
                $response['pesan'] = "Gagal mengubah password.";
            }
        } else {
            $response['hasil'] = false;
            $response['pesan'] = "Kode verifikasi salah atau sudah kadaluarsa.";
        }
    } else {
        $response['hasil'] = false;
        $response['pesan'] = "Aksi tidak valid.";
    }
} else {
    $response['hasil'] = false;
    $response['pesan'] = "Permintaan tidak valid.";
}

echo json_encode($response);
mysqli_close($koneksi);
?>
